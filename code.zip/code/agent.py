from utils import *

# super class of scheduling agnet
class Agent(object):
    def __init__(self):
        pass

    def get_action(self, obs):
        print('get_action not implemented')
        exit(1)
