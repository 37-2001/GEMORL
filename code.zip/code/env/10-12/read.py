import numpy as np
import os

def read_all(): # 全部读取并转换为txt
    npy_list = []
    file_list = os.listdir()

    for i in file_list:
        file_ext = os.path.splitext(i)
        front,ext = file_ext

        if ext == '.npy':
            npy_list.append(front)
    # print(npy_list)
    print('文件合计：',len(npy_list))
    i = 0
    fail_list = []
    for npy in npy_list:
        try:
            file = np.load(npy+'.npy',allow_pickle=True)
            print(npy)
            print(file)
            i += 1
            np.savetxt(npy+'.txt',file) # 转换为txt
        except:
            fail_list.append(npy)

    print('读取合计：',i)
    print(fail_list)

read_all()

def read_single(file_name): # 单读读取并转换(file_name不带后缀)
    file = np.load(file_name+'npy',allow_pickle=True)
    print(file)
    np.savetxt(file_name+ '.txt', file)  # 转换为txt

# read_single('task_duration_6')