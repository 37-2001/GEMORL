import numpy as np
import os

def txt_to_npy_all():
    file_list = os.listdir("C:\\Users\\DELL\\Desktop\\边\\decima-二维终版\\env\\16-18")
    for file_name in file_list:
        if file_name.endswith(".txt"):
            file = np.loadtxt("C:\\Users\\DELL\\Desktop\\边\\decima-二维终版\\env\\16-18\\" + file_name)
            np.save("C:\\Users\\DELL\\Desktop\\边\\decima-二维终版\\env\\16-18\\" + file_name[:-4] + ".npy", file)

txt_to_npy_all()