import numpy as np
import os
# C:\Users\DELL\Desktop\边钰薇-代码\code-v3 - hard-SOFT\env\4-6
def txt_to_npy_all():
    file_list = os.listdir("C:\\Users\\DELL\\Desktop\\边钰薇-代码\\code-v3 - hard-SOFT\\env\\4-6")
    for file_name in file_list:
        if file_name.endswith(".txt"):
            file = np.loadtxt("C:\\Users\\DELL\\Desktop\\边钰薇-代码\\code-v3 - hard-SOFT\\env\\4-6\\" + file_name)
            np.save("C:\\Users\\DELL\\Desktop\\边钰薇-代码\\code-v3 - hard-SOFT\\env\\4-6\\" + file_name[:-4] + ".npy", file)

txt_to_npy_all()