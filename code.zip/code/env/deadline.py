import numpy as np

def random_deadlines():
    ddr=[]
    for n in range(20):
        n=np.random.uniform(4, 15)
        ddr.append(n)
    return ddr
ddr=random_deadlines()

with open("deadlines.txt","w+") as fw:
    for i in range(len(ddr)):
        fw.write("{}\n".format(ddr[i]))



