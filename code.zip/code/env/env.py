import numpy as np

from param import *
from utils import *
from env.action_map import compute_node_act_map
from env.action_map import compute_mec_act_map
from env.reward_calculator import RewardCalculator
from env.job_generator import generate_jobs
from env.job_generator import generate_new_job
from env.wall_time import WallTime
from env.timeline import Timeline
from env.server import MEC
from env.global_mecs import GlobalMECs
from env.node import Node
from env.job_dag import JobDAG
from env.mec_commit import MecCommit


class Environment(object):
    def __init__(self):

        # isolated random number generator(随机数产生器)
        self.np_random = np.random.RandomState()
        # global timer（全局计时器）
        self.wall_time = WallTime()
        # uses priority queue（优先级队列）
        self.timeline = Timeline()
        # 用来存（node,mec）键值对
        self.mec_commit = MecCommit()
        # servers（服务器实例化）
        #### 假设最后一个服务器是本地服务器（i=args.num_mecs+1)
        self.mecs = OrderedSet()
        for i in range(args.num_mecs + 1):
            self.mecs.add(MEC(args.mec_capacity[i], args.mec_x[i], args.mec_y[i], i,
                              channel_busy=False, computation_busy=False))
        # 将服务器放到全局服务器里
        self.global_mecs = GlobalMECs(self.mecs)
        # prevent agent keeps selecting the same node（阻止智能体持续选择一个相同的节点）
        self.node_selected = set()
        # for computing reward at each step（在每时隙计算奖励）
        self.reward_calculator = RewardCalculator()
        # 传输带宽
        self.bandwidth = args.bandwidth

    def schedule(self):
        while len(self.mec_commit.commit) > 0:
            node = self.mec_commit.pop()
            if node is not None:
                mec = node.mec
                node.node_start_time = self.wall_time.curr_time

                ## 云计算
                if mec.idx == args.num_mecs:
                    duration = node.get_transmission_time() + node.data_size / (
                                args.cloud_rate * 1e6) + node.get_cloud_computation_time()

                ## 直接相连的服务器
                elif mec.idx == node.job_dag.access_mec_id:
                    duration = node.get_transmission_time() + node.get_computation_time()

                else:
                    # trans_time = node.get_transmission_time()+node.data_size/(args.trans_rate*1e6)
                    duration = node.get_transmission_time() + node.get_computation_time() + node.data_size / (
                                args.trans_rate * 1e6)

                node.node_finish_time = self.wall_time.curr_time + duration  ##原时间
                ##  加与hard deadline的比较
                if node.job_dag.var == "soft":
                    self.timeline.push(node.node_finish_time, node)

                if node.job_dag.var == "hard":
                    a = min(node.node_finish_time, node.job_dag.ddl + node.job_dag.start_time)
                    self.timeline.push(a, node)

    def get_frontier_nodes(self):
        # frontier nodes := unsaturated nodes with all parent nodes saturated
        frontier_nodes = OrderedSet()
        for job_dag in self.job_dags:
            for node in job_dag.nodes:
                if not node in self.node_selected and not self.saturated(node):
                    parents_saturated = True
                    for parent_node in node.parent_nodes:
                        if not self.saturated(parent_node):
                            parents_saturated = False
                            break
                    if parents_saturated:
                        frontier_nodes.add(node)
        return frontier_nodes

    def get_free_mecs(self):
        free_mecs = self.global_mecs.free_mecs
        return free_mecs

    # node完成代表已经饱和了
    def saturated(self, node):
        if node.node_done is True:
            return True

    # observe
    def observe(self):
        return self.job_dags, self.get_frontier_nodes(), \
               self.get_free_mecs(), self.node_action_map, self.mec_action_map

    def step2(self, next_node, next_mec):
        # mark = set()
        if next_node and next_mec is not None:
            # assert next_node not in self.node_selected
            self.node_selected.add(next_node)
            next_node.mec = next_mec
            next_node.mec.node = next_node
            self.global_mecs.free_mecs.remove(next_mec)
            self.mec_commit.add(next_node, next_mec)
        if len(self.global_mecs.free_mecs) == 0 or len(self.get_frontier_nodes()) == 0:
            self.schedule()

        while len(self.timeline) > 0 and (len(self.global_mecs.free_mecs) == 0 or len(self.get_frontier_nodes()) == 0):
            new_time, obj = self.timeline.pop()
            # print(new_time)
            self.wall_time.update_time(new_time)
            # 弹出同一时间点的事件并处理
            same_time_events = []
            same_time_events.append((new_time, obj))
            while len(self.timeline) > 0 and self.timeline.peek()[0] == new_time:
                new_time, event = self.timeline.pop()
                same_time_events.append((new_time, event))
            # 处理弹出的同一时间点的事件
            failed_jobs = set()

            for event_time, event_obj in same_time_events:
                if isinstance(event_obj, JobDAG):
                    ## 加判断
                    job_dag = event_obj
                    if job_dag.completed is not True:
                       self.failed_job_dags.add(job_dag)
                       failed_jobs.add(job_dag)

                if isinstance(event_obj, Node):
                    finished_node = event_obj
                    job_dag = finished_node.job_dag
                    mec = finished_node.mec
                    if job_dag.var == "hard" and finished_node.node_finish_time \
                            > job_dag.start_time + job_dag.ddl:
                        # self.failed_job_dags.add(job_dag)
                        failed_jobs.add(job_dag)
                        # self.mark_failed_jobs.add(job_dag)
                        # mark.add(job_dag)
                        if self.wall_time.curr_time >= self.max_time:
                            print('超时')
                            print('finished_node',finished_node.data_size)
                            print('mec',mec.mec_x)
                        mec.detach_node()
                        self.global_mecs.free_mecs.add(mec)
                    else:
                        finished_node.node_done = True
                        if finished_node in finished_node.job_dag.frontier_nodes:
                            finished_node.job_dag.frontier_nodes.remove(finished_node)
                        mec.detach_node()
                        self.global_mecs.free_mecs.add(mec)
                        job_dag.num_nodes_done += 1  # 对应job的node的完成个数递增一个
                        if job_dag.num_nodes_done == job_dag.num_nodes:  # 如果job中完成的节点个数等于job所有的节点个数，则job就完成了
                            job_dag.completed = True
                            job_dag.completion_time = self.wall_time.curr_time  # 记录job的完成时间
                            self.remove_job(job_dag)  # 从集合中移除job，向已完成的集合中添加Job
            if failed_jobs is not None:
                for job in list(failed_jobs):
                    i = job.idx
                    failed_jobs.remove(job)
                    self.job_dags.remove(job)
                    job_dag_new = generate_new_job(i, self.wall_time.curr_time)
                    self.job_dags.add(job_dag_new)
                    self.failed_job_dags.add(job_dag_new)
                    self.timeline.push(job_dag_new.start_time + job_dag_new.ddl, job_dag_new)
                    self.node_action_map = compute_node_act_map(self.job_dags)

        # 计算奖励
        reward1, reward2, reward3 = self.reward_calculator.get_reward(
            self.job_dags, self.wall_time.curr_time)
        # 判断是否完成
        done = len(self.timeline) == 0 or self.wall_time.curr_time >= self.max_time
        if done:
            if self.wall_time.curr_time >= self.max_time:
                print('超时')
        return self.observe(),reward1,reward2,reward3,done

    def remove_job(self, job_dag):
        self.job_dags.remove(job_dag)
        self.finished_job_dags.add(job_dag)
        self.node_action_map = compute_node_act_map(self.job_dags)

    def reset(self, max_time):
        self.max_time = max_time
        self.wall_time.reset()
        self.timeline.reset()
        self.reward_calculator.reset()
        self.finished_job_dags = OrderedSet()
        self.failed_job_dags = set()
        for mec in self.mecs:
            mec.reset()
        # generate a set of new jobs
        self.job_dags = generate_jobs(self.timeline)
        # map action to dag_idx and node_idx
        self.node_action_map = compute_node_act_map(self.job_dags)
        # map action to mec_idx
        self.mec_action_map = compute_mec_act_map(self.mecs)
        # self.mark_failed_jobs = set()
        self.hard_penalty=0
        self.soft_penalty=0
        self.job_duration=0

    def seed(self, seed):
        self.np_random.seed(seed)
