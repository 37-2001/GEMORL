from env.server import MEC
from utils import OrderedSet
from param import *

class GlobalMECs(object):
    def __init__(self,mecs):
        # 将传入的所有执行器放入全局执行器组中
        # 设置两个空集合分别存放空闲和被占用的mec
        # 其中初始的所有mec都是空闲的都放进空闲服务器组里

        self.global_mecs = {}
        for i in range (args.num_mecs):
            mec = MEC(mec_capacity=args.mec_capacity[i], mec_x=args.mec_x[i], mec_y=args.mec_y[i], idx=i,
                     channel_busy=False, computation_busy=False)
            self.global_mecs[i] = mec

        self.free_mecs =OrderedSet()
        for mec in mecs:
            self.free_mecs.add(mec)



