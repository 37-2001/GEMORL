import networkx as nx
import numpy as np
from utils import OrderedSet
from param import *
import math
# 定义了作业DAG的类

class JobDAG(object):

    # 初始化参数
    def __init__(self, nodes, adj_mat,  x, y,access_mec_id,ddl,idx):
        # nodes: list of N nodes（节点列表）
        # adj_mat: N by N 0-1 adjacency matrix, e_ij = 1 -> edge from i to j（邻接矩阵）
        assert len(nodes) == adj_mat.shape[0]   # 长
        assert adj_mat.shape[0] == adj_mat.shape[1]  # 宽
        # self.name = name
        self.nodes = nodes
        self.adj_mat = adj_mat
        self.idx=idx
        ### 指示变量 是hard 还是 soft 这里还需要改
        self.var = None
        self.num_nodes = len(self.nodes)
        self.num_nodes_done = 0
        # 横坐标
        self.x = x
        # 纵坐标
        self.y = y
        # 接入基站的id
        self.access_mec_id = access_mec_id
        self.ddl = ddl
        # the computation graph needs to be a DAG（计算图需要是一个DAG）
        assert is_dag(self.num_nodes, self.adj_mat)
        # get the set of schedule nodes（获取可以调度的节点集合）
        self.frontier_nodes = OrderedSet()
        for node in self.nodes:
            if node.is_schedulable():
                self.frontier_nodes.add(node)
        self.finished_nodes = OrderedSet()
        for node in self.nodes:
            if node.node_done is True:
                self.finished_nodes.add(node)
        self.assign_job_dag_to_node()

        # dag is arrived（DAG到达）
        self.arrived = False

        # dag is completed（完成）
        self.completed = False

        # dag start time（开始时间）
        self.start_time = None

        # dag completion time（完成时间）
        self.completion_time = np.inf

    def assign_job_dag_to_node(self):  # 分配作业到节点
        for node in self.nodes:
            node.job_dag = self

    def new_job(self,new_time):  # 重置
        for node in self.nodes:
            node.reset()
        self.num_nodes_done = 0
        self.start_time = new_time
        self.frontier_nodes = OrderedSet()
        for node in self.nodes:
            if node.is_schedulable():
                self.frontier_nodes.add(node)
        self.arrived = False
        self.completed = False
        self.completion_time = np.inf
        return self

    def reset(self):  # 重置
        for node in self.nodes:
            node.reset()
        self.num_nodes_done = 0
        self.frontier_nodes = OrderedSet()
        for node in self.nodes:
            if node.is_schedulable():
                self.frontier_nodes.add(node)
        self.arrived = False
        self.completed = False
        self.completion_time = np.inf

    def update_frontier_nodes(self, node):  # 更新可执行的节点
        frontier_nodes_changed = False
        for child in node.child_nodes:
            if child.is_schedulable():
                if child not in self.frontier_nodes:
                    self.frontier_nodes.add(child)
                    frontier_nodes_changed = True
        return frontier_nodes_changed

    def calculate_channel_gain(self):
        slow_fading = 1
        # d=math.sqrt()
        d = math.sqrt((float(self.x) - args.mec_x[self.access_mec_id]) ** 2 + (float(self.y)- args.mec_y[self.access_mec_id]) ** 2)
        path_loss = 10 ** (-(math.log10(d * 0.001) * 37.6 + 128.1) / 10)
        channel_gain = slow_fading * path_loss
        return channel_gain
    def calculate_transmission_rate(self):
        channel_gain = self.calculate_channel_gain()
        x = args.transmission_power * channel_gain / args.noise
        rate = args.bandwidth * math.log((1 + x), 2)
        return rate

    def energy_consumption(self):
        sum_energy = 0
        for node in self.nodes:
            sum_energy+=node.node_energy
        return sum_energy

def is_dag(num_nodes, adj_mat):
    G = nx.DiGraph()
    G.add_nodes_from(range(num_nodes))
    for i in range(num_nodes):
        for j in range(num_nodes):
            if adj_mat[i, j] == 1:
                G.add_edge(i, j)
    return nx.is_directed_acyclic_graph(G)