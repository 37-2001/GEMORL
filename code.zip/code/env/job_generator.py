from env.node import *
from env.job_dag import *
from param import *
import math


# 将坐标文件读入
with open("coordinate.txt", "r") as fw:
    lines = fw.readlines()
coordinate_list = []
for line in lines:
    x, y= line.split(" ")[0], line.split(" ")[1]
    coordinate_list.append([x, y])
# 将泊松分布的时间t读入
with open("possion.txt", "r") as fw:
    lines = fw.readlines()
t_list = []
for line in lines:
   t= line.split(" ")[0]
   t_list.append(t)
# 将数据量读入
with open("data_size.txt", "r") as fw:
    lines = fw.readlines()
data_sizes = []
for line in lines:
   data= line.split(" ")[0]
   data_sizes.append(data)
# 将cpu周期数读入
with open("cpu_circles.txt", "r") as fw:
    lines = fw.readlines()
cpu_circle= []
for line in lines:
   cpu= line.split(" ")[0]
   cpu_circle.append(cpu)
# 将deadline读入
with open("deadlines.txt", "r") as fw:
    lines = fw.readlines()
deadline_list = []
for line in lines:
   deadline= line.split(" ")[0]
   deadline_list.append(deadline)


def load_job(file_path, job_idx):
    # adj_mat
    adj_mat = np.load(
        file_path + 'adj_mat_' + str(job_idx) + '.npy', allow_pickle=True)
    assert adj_mat.shape[0] == adj_mat.shape[1]
    num_nodes = adj_mat.shape[0]
    # nodes
    nodes = []  # 生成节点的信息（CPU周期数cpu_circles，上传的数据量data_size)
    for n in range(num_nodes):
        BYTE = 8
        KB = 1024 * BYTE
        # data_size=450*KB
        data_size =float(data_sizes[n]) * KB
        # CPU clock frequency scales
        KHZ = 1e3
        MHZ = KHZ * 1e3
        GHZ = MHZ * 1e3
        # cpu_circles =1050*MHZ
        cpu_circles = float(cpu_circle[n]) * MHZ
        node = Node(n, cpu_circles, data_size)
        nodes.append(node)
    # parent and child node info
    for i in range(num_nodes):
        for j in range(num_nodes):
            if adj_mat[i, j] == 1:
                nodes[i].child_nodes.append(nodes[j])
                nodes[j].parent_nodes.append(nodes[i])

    x = coordinate_list[job_idx - 1][0]
    y = coordinate_list[job_idx - 1][1]
    # initialize descendant nodes初始化后代节点 递归查找后继节点
    for node in nodes:
        if len(node.parent_nodes) == 0:  # root
            node.descendant_nodes = recursive_find_descendant(node)
    # access_mec_id
    distance_list = np.zeros(args.num_mecs)
    for m in range(0, args.num_mecs):
        d = math.sqrt((float(x) - args.mec_x[m]) ** 2 + (float(y) - args.mec_y[m]) ** 2)
        distance_list[m] = d
    access_mec_id = np.argmin(distance_list)
    ddl= float(deadline_list[job_idx - 1])
    # generate DAG
    job_dag = JobDAG(nodes, adj_mat, x, y,access_mec_id,ddl,idx=job_idx)
    return job_dag


def recursive_find_descendant(node):
    if len(node.descendant_nodes) > 0:  # already visited
        return node.descendant_nodes
    else:
        node.descendant_nodes = [node]
        for child_node in node.child_nodes:  # terminate on leaves automatically
            child_descendant_nodes = recursive_find_descendant(child_node)
            for dn in child_descendant_nodes:
                if dn not in node.descendant_nodes:  # remove dual path duplicates
                    node.descendant_nodes.append(dn)
        return node.descendant_nodes

def generate_jobs(timeline):
    job_dags = OrderedSet()
    num_hard_jobs = int(args.num_stream_dags * args.bili)
    for i in range(num_hard_jobs):
        job_dag = load_job(args.job_folder, i + 1) ##i+1=job_idx=job.idx(从1开始到20）
        job_dag.var = "hard"  # 硬截止时间
        job_dag.start_time = t
        t_i = float(t_list[i])
        job_dag.start_time = t_i
        job_dag.arrived = True
        timeline.push(job_dag.ddl+job_dag.start_time, job_dag)
        job_dags.add(job_dag)

    for i in range(num_hard_jobs, args.num_stream_dags):
        job_dag = load_job(args.job_folder, i + 1 - num_hard_jobs)
        job_dag.var = "soft"  # 软截止时间
        t_i = float(t_list[i])
        job_dag.start_time = t_i
        job_dag.arrived = True
        job_dags.add(job_dag)

    return job_dags

def generate_new_job(i,time):
    job_dag_new = load_job(args.job_folder, i)
    job_dag_new.var = "hard"  # 硬截止时间
    job_dag_new.start_time = time
    job_dag_new.arrived = True
    return job_dag_new



