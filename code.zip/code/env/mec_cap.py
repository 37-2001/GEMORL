import numpy as np
def random_cap():
    mec_cap=[]
    for n in range(4):
        n=np.random.uniform(20, 30)
        mec_cap.append(n)
    return mec_cap
cap=random_cap()
print(cap)

