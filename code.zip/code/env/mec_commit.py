from collections import OrderedDict


class MecCommit(object):
    def __init__(self):
        self.commit = {}

    def __getitem__(self, node):
        return self.commit[node]

    def add(self, node, mec):
        self.commit[node] = mec

    def pop(self):
        # find the node in the map
        node = next(iter(self.commit))
        # deduct one commitment
        del self.commit[node]
        return node

    def reset(self):
        self.commit = {}

