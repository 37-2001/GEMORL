import time
from param import *
import math
import numpy as np
from utils import OrderedSet


# 定义任务类
class Node(object):
    def __init__(self, idx, cpu_circles, data_size):
        self.idx = idx   # 索引
        self.cpu_circles = cpu_circles  # 任务需要的CPU周期数
        self.data_size = data_size  # 任务所需上传的任务量的大小

        # uninitialized（未初始化的)
        self.parent_nodes = []  # 父节点初始为空列表
        self.child_nodes = []  # 子节点初始为空列表
        self.descendant_nodes = []  # 后继节点初始为空
        self.node_finish_time = np.nan  #
        self.node_start_time = np.nan
        self.node_estimated_start_time =np.nan
        self.transmission_completion_time =np.inf
        ## 用来记录能耗计算相关的时间，
        self.energy_time=np.inf
        self.node_energy = np.nan

        self.mec = None  # node所选的mec初始为空
        self.job_dag = None  # 工作为空
        self.transmission_completed = False
        self.computation_completed = False
        self.node_done = False

    def is_schedulable(self):  # 是否可调度
        if self.node_done is True:
            return False
        for node in self.parent_nodes:  # 循环遍历所有前向任务
            if node.node_done is False:
                return False
        return True

    # node的传输时间
    def get_transmission_time(self):
        channel_gain=self.job_dag.calculate_channel_gain()
        x = args.transmission_power * channel_gain / args.noise
        rate = args.bandwidth * math.log((1 + x), 2)
        transmission_time = self.data_size / rate
        return transmission_time

    # 节点在服务器的计算时间
    def get_computation_time(self):
        mec_capacity = self.mec.mec_capacity
        computation_time = self.cpu_circles / mec_capacity
        return computation_time

    def get_cloud_computation_time(self):
        computation_time = self.cpu_circles / args.cloud_cap
        return computation_time

    # 输入服务器的频率列表 获得节点的平均计算时间#加云更新版
    def get_avg_computation_time(self, mec_capacity_list):
        # 先计算总的计算时间
        sum = 0.0
        b = len(mec_capacity_list)  ##，这里放了云服务器在最后一个
        for n in mec_capacity_list:
            sum += self.cpu_circles / n
        avg_com_time= (sum+(b-1)*self.data_size/(args.trans_rate*1e6)+self.data_size/(args.cloud_rate*1e6))/b

        return avg_com_time

    def assigned_ddl(self):
        sum = 0.0
        for n in self.job_dag.nodes:
            molecule = n.get_transmission_time() + n.get_avg_computation_time(args.mec_capacity)
            sum += molecule
        assigned_ddl = self.job_dag.ddl*(self.get_transmission_time() +
                       self.get_avg_computation_time(args.mec_capacity)) / sum
        return assigned_ddl

    def reset(self):  # 重置函数
        self.node_finish_time = np.nan  # 初始化节点完成
        self.node_start_time = np.nan
        self.node_done = False
        self.mec = None
