import numpy as np

from param import *
def possion_point():
    t_list=[]
    t=0
    for i in range(args.num_stream_dags):
        t += np.random.exponential(0.1)
        t_list.append(t)
    return t_list
t=possion_point()
print(t)
with open("possion.txt","w+") as fw:
    for i in range(len(t)):
        fw.write("{}\n".format(t[i]))

