import numpy as np
from param import *
from utils import OrderedSet
class RewardCalculator(object):
    def __init__(self):
        self.job_dags = OrderedSet()
        self.prev_time = 0

    def get_reward(self, job_dags, curr_time):
        reward1 = 0
        reward2 = 0
        reward3 = 0
        for job_dag in job_dags:
            self.job_dags.add(job_dag)
        for job_dag in list(self.job_dags):
            if job_dag.var == "hard":
                reward1 -= (min(job_dag.completion_time, curr_time) - max(job_dag.start_time, self.prev_time))
                penalty = (min(job_dag.completion_time, curr_time) - max(job_dag.ddl + job_dag.start_time,self.prev_time))
                re = max(0, penalty)
                if re==0:
                    reward2-=0
                else:
                    reward2-=1
                if job_dag.completed:
                    self.job_dags.remove(job_dag)
            if job_dag.var == "soft":
                reward1 -= (min(job_dag.completion_time, curr_time) - max(job_dag.start_time, self.prev_time))
                penalty = (min(job_dag.completion_time, curr_time) - max(job_dag.ddl + job_dag.start_time,self.prev_time))
                reward3 -= max(0, penalty)
                if job_dag.completed:
                    self.job_dags.remove(job_dag)
        self.prev_time = curr_time
        return reward1,reward2,reward3

    def get_reward1(self, job_dags, curr_time):
        reward1 = 0
        for job_dag in job_dags:
            self.job_dags.add(job_dag)
        for job_dag in list(self.job_dags):
            reward1 -= (min(job_dag.completion_time,curr_time) - max(job_dag.start_time,self.prev_time))
            if job_dag.completed:
                    self.job_dags.remove(job_dag)
        self.prev_time = curr_time
        return reward1

    def get_reward2(self, job_dags, curr_time):
        reward2 = 0
        for job_dag in job_dags:
            self.job_dags.add(job_dag)
        for job_dag in list(self.job_dags):
            for node in job_dag.nodes:
                if node.node_done is False:
                    reward2 -= (min(node.energy_time,
                    curr_time) - max(node.node_start_time,self.prev_time))

            if job_dag.completed:
                self.job_dags.remove(job_dag)
        self.prev_time = curr_time
        return reward2

    def get_reward3(self, job_dags, curr_time):
        reward3 = 0
        for job_dag in job_dags:
            self.job_dags.add(job_dag)
        for job_dag in list(self.job_dags):
            for node in job_dag.nodes:
                if node.node_done is False:
                    reward3 -=  (min(node.transmission_completion_time,
                    curr_time) - max(node.node_start_time,self.prev_time))
            if job_dag.completed:
                self.job_dags.remove(job_dag)
        self.prev_time = curr_time
        return reward3



    def reset(self):
        self.job_dags.clear()
        self.prev_time = 0


