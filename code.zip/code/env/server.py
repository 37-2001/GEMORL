import math
import numpy as np
from param import *

class MEC(object):
    def __init__(self, mec_capacity, mec_x, mec_y, idx, channel_busy, computation_busy):
        self.mec_capacity = mec_capacity
        self.mec_x = mec_x
        self.mec_y = mec_y
        self.idx = idx
        self.channel_busy = channel_busy
        self.computation_busy = computation_busy
        self.node = None
        self.job_dag = None

    def reset(self):
        self.node = None
        self.channel_busy = False
        self.computation_busy = False

    def detach_node(self):
        # 如果mec中有节点，且如果Executor在其节点的执行器内，则将其从节点中移除
        if self.node is not None:
        # 重置Executor的节点属性
            self.node = None









