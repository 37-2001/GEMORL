import heapq
import itertools

# 管理优先级别的队列，是很常见的堆栈结构
# push的是会将元素放在尾部
# pop的是从头部弹出元素
# 具体用法可以参考：https://docs.python.org/3/library/heapq.html
class Timeline(object):
    def __init__(self):
        # priority queue
        self.pq = []
        # tie breaker（生成连续的数据点）
        self.counter = itertools.count()
    # 返回优先级队列中的元素个数
    def __len__(self):
        return len(self.pq)

    # 返回优先级队列中位置为0的元素
    def peek(self):
        if len(self.pq) > 0:
            (key, counter, item) = self.pq[0]
            return key, item
        else:
            return None, None

    # 将元素插入优先级队列中，压栈
    def push(self, key, item):
        heapq.heappush(self.pq,
            (key, next(self.counter), item))

    # 弹出并返回堆中的最小项，同时保持堆不变
    def pop(self):
        if len(self.pq) > 0:
            (key, counter, item) = heapq.heappop(self.pq)
            return key, item
        else:
            return None, None
    
    # 将本类重置
    def reset(self):
        self.pq = []
        self.counter = itertools.count()
